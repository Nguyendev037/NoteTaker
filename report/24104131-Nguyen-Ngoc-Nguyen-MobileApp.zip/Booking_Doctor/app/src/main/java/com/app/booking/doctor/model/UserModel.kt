package com.app.booking.doctor.model

class UserModel(
    var id: String = "",
    var userName: String = "",
    var name: String = "",
    var age: String = "",
    var phone: String = "",
    var sex: Int = 0,
    var avt: String = "",
) {

}