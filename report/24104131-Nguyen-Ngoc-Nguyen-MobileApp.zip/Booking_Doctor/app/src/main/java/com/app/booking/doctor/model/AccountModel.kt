package com.app.booking.doctor.model

class AccountModel(
    var userName: String,
    var password: String,
    var role: Int,
)